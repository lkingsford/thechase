class Teleporter:
    def __init__(self, location):
        self.location = location
