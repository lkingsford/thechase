class HealthPack:
    def __init__(self, location):
        self.location = location
